# Agent Execution Integrity Benchmark (AEIB) v1.0 (Zone 1 Open Core)

[![License: Apache-2.0](https://img.shields.io/badge/License-Apache--2.0-blue.svg)](LICENSE)

AEIB is a lightweight research prototype providing a versioned transport-to-disposition mapping contract (`docs/transport-to-disposition-mapping.yaml`), Canonical Action Identifier (CAID) derivation via RFC 8785 JSON Canonicalization Scheme (JCS), execution governor logic, and offline evidence receipt verification for structured research agent workflows.

---

## 🏛️ Core Boundary Principle: "Verified is not Released"

> An AEIB receipt is a verification artifact, not a release decision. It records the canonical action binding, transport observation, available reconciliation evidence, mapping version, and resulting disposition. A separate authority or policy layer must decide whether any subsequent action may be released, and an enforcement layer must ensure that the decision is applied.

### The 3-Stage Architectural Distinction
1. **Stage 1 — Verification (AEIB Core Role):** Evaluates whether recorded evidence is authentic, complete, and sufficient under the declared transport-to-disposition contract. Emits an Ed25519-signed, JCS-canonicalized (RFC 8785) receipt.
2. **Stage 2 — Release (Downstream Policy Gate):** Determines whether an authorized decision-maker or policy permits external consequence release or retry. AEIB does not independently authorize release.
3. **Stage 3 — Enforcement (Runtime Lockout Latch):** Ensures that a release or lockout decision is applied locally.

---

## 🧪 Verification Commands

To verify the open-core release package locally:

```bash
# 1. Zone Boundary Check (Zero Zone 2 imports)
python3 compliance/check_zone_boundary.py

# 2. AST Purity & Zero-Mock Check (Zero stubs, zero mocks)
python3 compliance/ast_purity.py .
python3 compliance/no_mock_enforcer.py

# 3. Comprehensive Academic Replication Suite (41 Passing Tests)
python3 replication/reproduce_all.py

# 4. Deterministic 500-Episode Benchmark Harness
python3 benchmarks/aeib_execution_integrity/run_episodes.py --episodes 500 --seed 42

# 5. Offline Mapping & Receipt Verifier
python3 aeib_verify.py
```

---

## 📊 Summary of Baseline Benchmark Results (Seed 42)

* **Arm 1 (Naive Retry Baseline):** 500 / 500 duplicate writes (100.0% failure rate by construction).
* **Arm 2 (Payload Hash Key):** 314 / 500 duplicate writes (62.8% failure under prompt mutations).
* **Arm 3 (Server-Side Stable Key):** 0 duplicate writes, 99 unresolved drops.
* **Arm 4 (AEIB Protocol):** **0 duplicate writes**, **368 retry attempts blocked** (334 by gate probe, 34 by ledger idempotency). Rule-of-Three 95% CI upper bound $\le 0.60\%$.

---

## ⚠️ Known Limitations & Epistemic Boundaries

1. **Simulation Model Bounds:** The 500-episode harness is a deterministic simulation of the retry-duplication mechanism over 15 fault classes using an in-memory ledger. It evaluates internal protocol consistency, not live network traffic. The Rule-of-Three bound ($\le 0.60\%$) applies to this simulation model only.
2. **Industrial Terminology:** Industrial-protection analogies (ANSI 50BF, ANSI 86, etc.) are conceptual software patterns only; AEIB does not implement physical ANSI/IEEE/IEC relay standards or interoperate with hardware power grid devices.
3. **Target System Idempotency:** Provider-side settlement remains dependent on target system idempotency capabilities or queryable status endpoints.

---

## 📄 Licensing

Distributed under the **Apache License 2.0**. See [`LICENSE`](LICENSE) for details.
