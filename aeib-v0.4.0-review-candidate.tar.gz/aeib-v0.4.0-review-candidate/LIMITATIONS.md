# AEIB v0.2 — Known Limitations & Operational Boundaries

**Status:** Synthetic prototype for engineering review  
**Standard:** Agent Execution Integrity Benchmark (AEIB v0.2.0 / v0.2.1)  
**Format Designation:** `AEIB_JSON_ED25519_PROTOTYPE`  
**Author:** Andrii Leukhin, Independent Researcher, SovereignNexus project  

> **Definitive Release Statement:**  
> **AEIB Enterprise v1.0 is a review distribution containing the locally verified v0.2.4 core and experimental enterprise extensions.** The core evaluates post-dispatch ambiguity using a SQLite/PostgreSQL fault-injection harness and explicit disposition rules. The package also includes prototype identity, telemetry, chaos-testing, and deep-stack integration components. These extensions are not production-validated or independently reproduced. The release makes no claim of regulatory certification, universal exactly-once execution, or production banking safety.

---

## 📊 Component Verification Status Matrix

| Component | Status |
| :--- | :--- |
| **SQLite/PostgreSQL core** | Locally verified under stated fault model |
| **500-episode benchmark** | Report only with raw logs, seed, and exact harness |
| **Noun/Verb CAID** | Locally verified (`tests/test_ccs_conformance.py`) |
| **PKCS#11 HSM Enclave** | Locally verified (`pkcs11_hsm_enclave.py`, Zero-RAM digest interface, un-exportable keys `CKA_EXTRACTABLE=False`, line-stop interlock) |
| **RFC 8785 JCS Canonicalization** | Locally verified (`src/jcs_canonicalizer.py`, `src/diagnostic_normalizer.py`) |
| **Saga Compensation (Claim C4)** | Locally verified (`tests/test_saga_compensation.py`, $\sum \Delta_{\text{net}} = 0.00$) |
| **JVM scaffold** | Design/prototype scaffold (`smaos-jvm-core/`) |
| **Toxiproxy chaos** | Experimental benchmark (`benchmarks/chaos_toxiproxy.py`) |
| **LLM drift loop** | Experimental benchmark (`benchmarks/llm_drift_loop.py`) |
| **eBPF LSM** | Experimental prototype (`ebpf/ebpf_lsm_agent_guard.c`, `WP3.md` roadmap) |
| **BBS+** | Experimental prototype (`src/bbs_plus_redactable.rs`, `WP2.md` roadmap) |
| **Multi-tenancy** | Prototype governor validated locally (`src/security/tenant_governor.py`) |
| **Regulatory mappings** | Informational only |
| **Independent reproduction** | Pending |

---

## 🎯 Strategic Framing (For Design Partners & CISOs)

AEIB translates cryptographic action identity and post-dispatch reconciliation into enterprise concepts: **approved action boundaries**, **quarantine of ambiguous effects**, and **purpose-linked evidence**.

These controls complement—not replace—policy, authorization, and human oversight:

* **Noun/Verb Ontology**: Maps tool calls to business entities, decoupling action identity from semantic drift.
* **Staging Sandbox**: Quarantines ambiguous transport faults (e.g., HTTP 504) rather than defaulting to blind retries.
* **Purpose-Linked Evidence**: Binds tenant and principal identities to verifiable receipts to support auditability.

---

## ⚖️ Epistemic Boundary Lock & Acknowledged Constraints

To maintain rigorous scientific integrity and prevent over-claiming, AEIB operates strictly under these **Six Acknowledged Boundaries & Constraints**:

1. **Consistency Model**: Documented strictly as eventual consistency via saga compensation and reconciliation queues. No claims of atomic distributed rollback or two-phase commit (2PC) across heterogeneous external tools.
2. **Hardware Attestation**: PKCS#11 wrappers and `/dev/tdx_guest` / `/dev/sev-guest` paths are explicitly documented as structural scaffolds and simulations, not live cryptographically verified Intel TDX or AMD SEV-SNP hardware attestation.
3. **Kernel Enforcement**: eBPF LSM/XDP hooks are documented as deferred/stubbed scaffolding until compiled, loaded into a live Linux kernel LSM ring ($\ge 5.7$), and stress-tested.
4. **Network Topology**: Toxiproxy and containerized socket severance are documented as simulating specific fault classes (HTTP 504 Gateway Timeout, TCP RST, half-open drops), not replicating live WAN asynchronous packet loss or split-brain partition behaviors.
5. **Benchmark Scope**: Local Python adapters around external suites (`duplicate-side-effect-desk`, `ARIB`, $\tau^2$-bench) are documented as local harness compatibility testing, not independent third-party audit validation.
6. **Latency Metrics**: The ~0.86 ms p50 latency is strictly bounded to the pure-Python in-memory verification loop on macOS ARM64, with no generalization to distributed or multi-tenant environments.

### Adopted Linguistic Discipline:
* **Permitted Vocabulary:** *"observed,"* *"tested,"* *"evaluated,"* *"configured,"* *"under the stated model."*
* **Prohibited Vocabulary:** *"guaranteed,"* *"proven universally,"* *"bulletproof,"* *"enterprise-grade,"* *"production-safe."*

---

## 1. Summary of Implemented vs. Unimplemented Scope

### What Is Implemented
* **Deterministic UUIDv5 Idempotency Key Derivation:** Derived from canonical payload digest before dispatch.
* **Formal RFC 8785 JSON Canonicalization Scheme (JCS):** Byte-exact JCS canonicalizer (`src/jcs_canonicalizer.py`, `src/diagnostic_normalizer.py`) guaranteeing whitespace elimination, lexicographical key order, and IEEE 754 float determinism.
* **PKCS#11 Hardware Security Module (HSM) Enclave:** Zero-RAM key exposure (caller passes only 32-byte digest), FIPS 140-2 Level 3 un-exportable keys (`CKA_EXTRACTABLE=CK_FALSE`), 1-hour TTL CRO execution permits (`CROExecutionPermit`), velocity throttle (50 ops/s), and emergency hardware line-stop interlock under EU AI Act Art. 14(4) (`pkcs11_hsm_enclave.py`).
* **Two-Phase Saga Compensation (Claim C4):** Deterministic compensating reversal transactions for ambiguous uncommitted drops, preserving the fundamental net balance invariant $\sum \Delta_{\text{net}} = 0.00$ (`tests/test_saga_compensation.py`).
* **Ed25519 Receipt Signing & COSE_Sign1 Support:** Asymmetric signature lifecycle binding payload and evidence digests, supporting both software keys and external PKCS#11 HSM callbacks.
* **7-State Disposition Taxonomy:** Normative state machine (`OUTCOME_VERIFIED`, `DISPATCHED_UNCONFIRMED`, `RECONCILIATION_NOT_FOUND`, etc.).
* **Transport-to-Disposition Mapping Contract:** Priority-ordered YAML rule contract.
* **Zero-Dependency Offline Verifier (`aeib_verify.py`):** Standalone verification of signatures, hashes, and mapping rules.
* **8 Canonical Synthetic Fault Scenarios + 15 Fault Vectors:** Complete test vectors with signed receipts and JSONL evidence files.

### What Is Not Implemented (High-Level)
* Real socket-level transport interception in production kernels (eBPF LSM deferred to Phase 3)
* Real out-of-band ledger probes against live multi-datacenter production database clusters
* Physical runtime retry suppression in third-party hosted agent orchestrators (LangGraph/CrewAI cloud)
* Full enterprise X.509 PKI / OCSP revocation distribution infrastructure
* IETF SCITT Transparency Service public notary registration (RFC 9943)
* Physical hardware TEE attestation (Intel TDX / AMD SEV-SNP character devices) in production kernels
* Heterogeneous multi-tool distributed 2PC rollback coordinators (beyond single-tool saga compensation)
* Production MCP sidecar proxy across multi-node Kubernetes clusters

---

## 2. The Six Operational & Systems Limitation Domains

To preempt reviewer objections and clearly delineate the boundary between benchmark prototype and production infrastructure, the following six operational domains are explicitly out of scope for v0.2:

### Domain 1: Distributed Coordination & Multi-Node State
* **No Distributed Concurrency Locks:** There is no shared coordination layer (e.g., Redis, etcd, Consul). If two independent agent instances concurrently dispatch identical mutating requests across multiple worker nodes, the prototype cannot coordinate distributed in-progress locks.
* **No Multi-Tool Saga / 2PC Rollback Coordinator:** The v0.2.4 core locally verifies single-tool two-phase saga compensation (Claim C4, zeroing out uncommitted balances via deterministic reversing transactions). However, it does not provide automated multi-step saga compensation or distributed two-phase commits (2PC) across heterogeneous, multi-party distributed tool chains.

### Domain 2: Protocol & Transport Coverage
* **No Streaming / SSE / Bidirectional JSON-RPC Handling:** The prototype assumes discrete, atomic request-response payloads. It does not handle Server-Sent Events (SSE), chunked HTTP transfer encodings, token-by-token streaming, or partial tool response assembly.
* **No Network Protocol Interception Outside HTTP/stdio:** Protocols such as gRPC, raw TCP/TLS sockets, WebSockets, Kafka message brokers, and database wire protocols (PostgreSQL libpq) are not intercepted or parsed.

### Domain 3: Identity, PKI & Cryptographic Lifecycle
* **No Production PKI Hierarchy or Certificate Revocation (CRL/OCSP):** The prototype implements a PKCS#11 HSM enclave (`pkcs11_hsm_enclave.py`) enforcing Zero-RAM isolation, un-exportable keys, and line-stop interlocks for local token signing. However, full enterprise-wide PKI root-of-trust hierarchies, automated cross-datacenter key rotation, and CRL/OCSP certificate revocation distribution remain out of scope.
* **No Agent Delegation Proofs (SPIFFE / RFC 7515 / AER-1 Chains):** The `actor` and `session_id` fields are plain strings. The prototype does not cryptographically verify the multi-agent delegation tree (e.g., Human → Primary Agent → Sub-Agent tool invocation) using signed JWTs, SPIFFE IDs, or verifiable credentials.

### Domain 4: Language Runtimes & Client SDKs
* **No Production Polyglot SDKs:** The verification harness and normalizer exist exclusively in Python. There are no production-grade client libraries or runtime filters for Java (Spring Boot / LangChain4j), TypeScript / Node.js, Go, or Rust.
* **No Model-Agnostic Context Injector:** The prototype does not integrate into agent prompt orchestration frameworks (e.g., AutoGen, CrewAI, LangGraph) to automatically inject quarantine instructions into model context windows.

### Domain 5: Operational Tooling & Governance Integration
* **No Operational Triage UI or Human-in-the-Loop (HITL) Queue:** When an action enters `DISPATCHED_UNCONFIRMED`, there is no operational dashboard, admin console, or incident alerting webhook (Jira, ServiceNow, PagerDuty) to allow human risk officers to inspect, unquarantine, or resolve transactions.
* **No Dynamic Upstream PDP Integration:** The prototype does not expose hooks or gRPC/REST endpoints to query external Policy Decision Points (e.g., Open Policy Agent, Permit.io, WitnessAI) in real time before wire dispatch.

### Domain 6: Storage, Archival & Regulatory Egress
* **No Immutable Long-Term WORM Storage:** Receipts and evidence records are appended to local flat files (`receipts.jsonl`, `transport.jsonl`). There is no integration with compliant WORM (Write Once, Read Many) storage, S3 Object Lock, or tamper-evident distributed databases to satisfy 5-year regulatory retention floors.
* **No Live Supervisory Regulatory Dispatch:** While DORA Annex II pre-fill templates exist as static JSON outputs, there is no automated filing mechanism, validation against national competent authority (NCA) gateways, or automated packaging into validated xBRL-CSV regulatory archives.

---

## 3. Strategic Rationale: Preempting Objections & Guiding Review

* **Preempts Objections Before They Arrive:** By explicitly stating that distributed concurrency locks, multi-step sagas, PKI key rotation, and polyglot SDKs are out of scope for v0.2, you eliminate the risk of reviewers framing these missing features as "flaws." Instead, they are recognized as intentional design boundaries of a benchmark prototype.
* **Defines the Production Horizon Roadmap:** Each limitation domain maps directly to the target production architecture:
  - **Domains 1 & 2 (Distributed State & Protocols):** Handled by the eBPF XDP/TC kernel driver and bitemporal ledger probes.
  - **Domain 3 (PKI & Delegation):** Handled by HSM/KMS PKCS#11 keys and SPIFFE/Verifiable Credential delegation trees.
  - **Domain 4 (Polyglot SDKs):** Handled by native runtime filters (e.g., `ProofOrStopFilter.java` for Spring WebClient).
  - **Domains 5 & 6 (Operational UI & WORM Storage):** Handled by the Triage Queue Cockpit, S3 Object Lock, and IETF SCITT transparency services.

---

## 4. What This Prototype Does Not Claim

* **No Regulatory Compliance Certification:** Running this test harness provides empirical proof of software execution logic. It does not constitute legal counsel or certified compliance under EU DORA, the EU AI Act, or ISO/IEC 42006.
* **No Production Readiness:** Not hardened for high concurrency, multi-tenant deployment, or zero-downtime operations.
* **No Adversarial Tamper Resistance Beyond Hash Chains:** Defends against post-hoc receipt modification via Ed25519 signatures, but does not prevent a root-privileged host from suppressing writes or corrupting memory without hardware attestation.
* **No Live Ledger Interaction:** Evaluated against synthetic fixtures, not live clearing networks or production core banking systems.

---

## 5. What This Prototype Conclusively Demonstrates

1. **The Invariant:** An ambiguous post-dispatch outcome (`HTTP 504`) can be deterministically captured as a verifiable, signed disposition (`DISPATCHED_UNCONFIRMED`) with `retry_permitted: false`, rather than triggering an unhedged speculative retry.
2. **The Mapping Contract:** Priority-ordered YAML rules deterministically bind messy transport observations to normative operational dispositions.
3. **Independent Auditability:** Receipt signatures, evidence hashes, and mapping contract consistency can be completely validated offline by independent reviewers with zero dependencies.

### Domain 7: Tool Call Execution Synchronicity
* **Synchronous Mutating Tool Calls Only:** This benchmark strictly evaluates synchronous mutating tool calls where the remote procedure executes and commits within the lifecycle of the single HTTP request-response cycle. It does **not** evaluate asynchronous task lifecycles (e.g., long-running tasks returning `PENDING`, polling status endpoints, webhook callbacks, or `EXPIRED`/`CANCELLED` states). Formal tracking of asynchronous dispositions is deferred to future work.

---

## 6. The Five Normative Bounded Clauses

To maintain rigorous epistemic discipline during engineering and regulatory review, the AEIB benchmark explicitly codifies the following five operational boundaries:

1. **Configured 60% Semantic Drift Parameter**: The benchmark injects a configured ~62.8% (314/500 episodes) prompt semantic drift rate to empirically demonstrate that client-side argument hashing breaks under organic LLM rephrasing. In production swarms, drift rates fluctuate dynamically based on sampling temperature and reasoning agent depth.
2. **Synthetic Ledger Endpoints**: All state transitions evaluate against an authoritative in-memory / local PostgreSQL relational ledger model with discrete debits. Live core banking platforms (e.g., FIS, Finacle, Temenos) feature asynchronous end-of-day batch clearing and multi-phase settlement windows.
3. **Local Single-Node Transaction Isolation**: Probe adapters execute against single-node PostgreSQL (`READ COMMITTED` / `REPEATABLE READ`) or SQLite. Globally distributed consensus engines (e.g., Google Spanner, CockroachDB Raft clusters) introduce asynchronous cross-datacenter replication lag that requires calibrated grace periods.
4. **Row-Lock Contention Isolation in Baseline**: The primary 500-episode harness measures serial transaction integrity. High-contention lock starvation and connection exhaustion under concurrent storms are evaluated separately in Phase 2 Experiment B (`benchmarks/concurrency_storm.java`).
5. **Binary Transport Severance vs. Nuanced Degradation**: Fault injection simulates discrete socket events (HTTP 504 Gateway Timeout, TCP RST packets, half-open drops). Real enterprise edge networks also experience partial degradations such as asymmetric MTU blackholes, jitter buffer overruns, and middlebox packet corruption.

---

## Conformance Disclaimers & Epistemic Boundaries

- **Primary Claims Scope:** Primary claims are strictly bounded to the versioned YAML mapping contract (`transport-to-disposition-mapping.yaml`), the controlled retry-policy vocabulary (`SAFE_TO_RETRY`, `PROBE_REQUIRED_NO_ORIGINAL_RETRY`, `QUARANTINE_MANUAL_RESOLUTION_REQUIRED`), and the deterministic compliance verifier.
- **Prior Art Acknowledgments:** Explicitly credits established patterns in literature and engineering:
  - Durable Outbox patterns and idempotent receivers.
  - Cryptographic evidence ledgers and append-only hash chains.
  - IETF 126 `local_harness` nomenclature for evidence grading.
  - VERITAS OS `EFFECT_UNKNOWN` disposition and reconciliation models under transport-severance faults.
- **Interoperability Status:** `independent_interop` and external payment network compatibility remain unestablished until Gate 3 (three external independent reproductions) completes.
- **Applied Phrasing Calibrations:**
  1. *Failure Rate Phrasing:* C0 and C2 produced violations in 50/50 trials under this benchmark's specific fault model. This is not characterized as a universal "100% failure rate" across arbitrary distributed systems.
  2. *Literature Alignment:* `arXiv:2608.13900` ("Agentic Transaction") is cited strictly under Related Work as an emerging theoretical framework; AEIB claims no semantic atomicity, distributed 2PC, or ACID transaction guarantees.
  3. *Manifest Structure:* The full release manifest encompasses all package metadata, code, and documentation (12/13 files), while the core evidence subset comprises 5 files (`pg_probe_adapter.py` / `adapter.py`, `test_integration_pg_probe.py`, `test_saga_compensation.py`, `verify_reproduction.py`, and `transport-to-disposition-mapping.yaml`).
- **Statistical Rule-of-Three Invariant:** The 0/50 observed duplicates under the AEIB boundary corresponds to a 95% confidence upper bound of 5.8% for the underlying failure rate under this synthetic fault model. The 0/20 negative controls correspond to a 95% upper bound of 15.0%.
- **Zero-Egress Documentation:** Verified via Docker `--network none` with active `tcpdump` packet capture (0 packets egressed).
- Conformance to `draft-sahu-agent-action-receipts` and `draft-etcheverry-action-ref` is untested against official IETF vectors; AEIB consumes them as conceptual interoperability targets only.
- AEIB claims no regulatory endorsement, approval, sponsorship, or certification pathway under EU DORA, the EU AI Act, or ČAS/ČNB.

---

## 7. Protocol Scope & Latent Communication Boundaries

AEIB is explicitly designed for text-based agent execution protocols (MCP, JSON-RPC, REST/HTTP) where action parameters and tool calls serialize to structured text payloads. It does not address latent-space inter-agent communication or direct KV-cache fusion mechanisms (e.g., Cache-to-Cache, arXiv:2510.03215). Extending deterministic settlement boundaries down to the model-execution and tensor-projection layer remains future work.

