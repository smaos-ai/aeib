#!/usr/bin/env python3
# Copyright 2026 SovereignNexus Project
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
aei_core/model/evidence.py
Evidence data models for Agent Execution Integrity (AEIB).
"""

from enum import Enum
from datetime import datetime
from typing import Dict, Any, Optional
from dataclasses import dataclass


class EvidenceType(str, Enum):
    PROBE_RESULT = "PROBE_RESULT"
    OBSERVATIONAL = "OBSERVATIONAL"
    AUTHORITATIVE = "AUTHORITATIVE"
    RECEIPT = "RECEIPT"
    SETTLEMENT = "SETTLEMENT"


@dataclass
class EvidenceRecord:
    evidence_id: str
    evidence_type: EvidenceType
    source: str
    timestamp: datetime
    payload: Dict[str, Any]
    authority_level: str = "OBSERVATIONAL"
