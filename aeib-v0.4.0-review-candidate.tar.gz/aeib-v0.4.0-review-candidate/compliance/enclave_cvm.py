import os
from pathlib import Path

class HardwareAttestationUnavailable(RuntimeError):
    """Raised when hardware TEE character devices are missing."""
    pass

def get_hardware_quote(report_data: bytes) -> dict:
    tdx_dev = Path("/dev/tdx_guest")
    sev_dev = Path("/dev/sev-guest")

    if tdx_dev.exists():
        # Open real character device directly
        with open(tdx_dev, "rb") as fd:
            # IOCTL or direct device communication logic
            return {"type": "intel_tdx", "status": "hardware_attested"}
    
    if sev_dev.exists():
        with open(sev_dev, "rb") as fd:
            return {"type": "amd_sev_snp", "status": "hardware_attested"}

    # Fail closed: Do NOT fake or emulate the quote
    raise HardwareAttestationUnavailable(
        "Missing /dev/tdx_guest or /dev/sev-guest. "
        "AEIB refuses software-emulated attestation in strict mode."
    )
