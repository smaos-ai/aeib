#!/usr/bin/env python3
r"""
mcp_schema_pinning.py - MCP Tool Schema Pinning & Integrity (Acceptance Test 14)

Binds each approved MCP tool schema to a canonical digest computed as
SHA256(JCS(schema)) using the repository's single canonicalization source of
truth (src/jcs_canonicalizer.encode_jcs), so key order and whitespace cannot
smuggle a mutation past review, while any semantic change to descriptions,
parameters, default values, or endpoints changes the digest.

On mismatch the verifier raises SchemaMutationRejected, whose .code is
MCP_SCHEMA_MUTATION_REJECTED, so CI and gateway layers can alert on the
exact rejection reason.

Zero-mock: digests are real SHA-256 over real RFC 8785 bytes; there are no
shortcuts or test-only branches.
"""

import hashlib

try:
    from src.jcs_canonicalizer import encode_jcs
except ImportError:  # direct script execution / pythonpath = src
    from jcs_canonicalizer import encode_jcs

MCP_SCHEMA_MUTATION_REJECTED = "MCP_SCHEMA_MUTATION_REJECTED"


class SchemaMutationRejected(ValueError):
    """Raised when a tool schema no longer matches its approved pin."""

    def __init__(self, tool_name: str, expected: str, actual: str) -> None:
        self.code = MCP_SCHEMA_MUTATION_REJECTED
        self.tool_name = tool_name
        self.expected = expected
        self.actual = actual
        super().__init__(
            f"{MCP_SCHEMA_MUTATION_REJECTED}: tool {tool_name!r} schema "
            f"digest changed (approved {expected}, observed {actual})"
        )


class UnknownToolRejected(ValueError):
    """Raised fail-closed when no approved pin exists for the tool."""

    def __init__(self, tool_name: str) -> None:
        self.code = MCP_SCHEMA_MUTATION_REJECTED
        self.tool_name = tool_name
        super().__init__(
            f"{MCP_SCHEMA_MUTATION_REJECTED}: no approved schema pin for "
            f"tool {tool_name!r} (fail closed)"
        )


def compute_tool_schema_hash(schema: dict) -> str:
    """
    Canonical tool_schema_hash = SHA256(JCS(schema)), hex-encoded with a
    sha256: prefix. Uses encode_jcs so the digest is byte-identical to every
    other canonicalization in the repository (UTF-16 code-unit key order,
    ECMAScript number rules, no normalization inside JCS).
    """
    if not isinstance(schema, dict):
        raise TypeError("schema must be a JSON object")
    canonical = encode_jcs(schema)
    return "sha256:" + hashlib.sha256(canonical).hexdigest()


class ToolSchemaPins:
    """Registry of approved tool schema digests (pin once, verify always)."""

    def __init__(self) -> None:
        self._pins = {}

    def pin(self, tool_name: str, schema: dict) -> str:
        """Approve the current schema; returns the recorded digest."""
        digest = compute_tool_schema_hash(schema)
        self._pins[tool_name] = digest
        return digest

    def verify(self, tool_name: str, schema: dict) -> str:
        """
        Verify a schema against its approved pin.
        Raises SchemaMutationRejected on any semantic change and
        UnknownToolRejected fail-closed when no pin exists.
        """
        expected = self._pins.get(tool_name)
        if expected is None:
            raise UnknownToolRejected(tool_name)
        actual = compute_tool_schema_hash(schema)
        if actual != expected:
            raise SchemaMutationRejected(tool_name, expected, actual)
        return actual

    def pinned(self, tool_name: str) -> bool:
        return tool_name in self._pins
