# AEIB Zero-Mock Benchmark Pack (v1.1.0)
## US Banking SR 26-2 & MITRE v20 Model Risk Management Proofs

This evidence archive contains four mathematically verifiable proof bundles demonstrating
consequence-weighted agent execution integrity at Layer 7 wire boundaries:

1. **Proof 1: Prevention of AI-Enabled Exfiltration (MITRE v20 T1048)**
   - Files: `proofs/proof_1_exfiltration/`
   - Description: Demonstrates that credential smuggling or recipient alterations inside payment memos are rejected pre-dispatch with 0 bytes transmitted.

2. **Proof 2: Protection Against Temporal State Drift (SR 26-2 Invariant)**
   - Files: `proofs/proof_2_temporal_drift/`
   - Description: Proves that policy epoch rotations and authority revocations during inference block execution before socket allocation.

3. **Proof 3: Immunity to AI Result Poisoning (MITRE v20 T1565)**
   - Files: `proofs/proof_3_result_poisoning/`
   - Description: Proves that forged 200 OK statuses and operation ID tampering trap into EFFECT_INDETERMINATE fail-closed.

4. **Proof 4: The 500-Episode Chaos Simulation**
   - Files: `proofs/proof_4_chaos_simulation/`
   - Description: 500 episodes under 15 fault vectors. Result: 0 duplicate writes, 302 duplicate attempts blocked.

### Offline Cleanroom Verification

#### Python CLI (Zero Egress):
```bash
python3 verifiers/verify_pack.py
```

#### Browser WASM (Zero Egress, connect-src 'none'):
Open `verifiers/smaos-verify.html` in an air-gapped web browser and inspect evidence bundles offline.
