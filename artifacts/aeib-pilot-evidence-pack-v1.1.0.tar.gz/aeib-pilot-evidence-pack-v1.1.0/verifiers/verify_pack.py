#!/usr/bin/env python3
"""
verifiers/verify_pack.py
================================================================================
Standalone Clean-Room Verification Engine for AEIB Zero-Mock Benchmark Pack.
Evaluated under the stated model. Preserves strict epistemic lock.
Zero network egress. Verifies RFC 8785 JCS digests and Ed25519 signatures.
"""

from __future__ import annotations

import base64
import hashlib
import json
import sys
from pathlib import Path
from typing import Any, Dict

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

PACK_DIR = Path(__file__).resolve().parent.parent


def encode_jcs(val: Any) -> bytes:
    """Strict RFC 8785 JSON Canonicalization Scheme (JCS)."""
    if val is None:
        return b"null"
    if isinstance(val, bool):
        return b"true" if val else b"false"
    if isinstance(val, int):
        return str(val).encode("utf-8")
    if isinstance(val, float):
        if val != val or val == float("inf") or val == float("-inf"):
            raise ValueError(f"JCS does not support non-finite float {val}")
        if val.is_integer():
            return str(int(val)).encode("utf-8")
        s = f"{val:.16g}"
        return s.encode("utf-8")
    if isinstance(val, str):
        return json.dumps(val, ensure_ascii=False).encode("utf-8")
    if isinstance(val, list):
        items = [encode_jcs(x) for x in val]
        return b"[" + b",".join(items) + b"]"
    if isinstance(val, dict):
        sorted_keys = sorted(
            val.keys(),
            key=lambda k: k.encode("utf-16-be")
        )
        parts = []
        for k in sorted_keys:
            encoded_k = json.dumps(k, ensure_ascii=False).encode("utf-8")
            encoded_v = encode_jcs(val[k])
            parts.append(encoded_k + b":" + encoded_v)
        return b"{" + b",".join(parts) + b"}"
    raise TypeError(f"Type {type(val)} not serializable in RFC 8785 JCS")


def verify_manifest():
    manifest_path = PACK_DIR / "MANIFEST.json"
    if not manifest_path.exists():
        print("[!] MANIFEST.json missing", file=sys.stderr)
        sys.exit(1)
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    files = manifest.get("files", {})
    print(f"[*] Verifying {len(files)} files against MANIFEST.json...")
    for rel_path, meta in files.items():
        fpath = PACK_DIR / rel_path
        if not fpath.exists():
            print(f"[!] Missing file: {rel_path}", file=sys.stderr)
            sys.exit(1)
        actual_sha = hashlib.sha256(fpath.read_bytes()).hexdigest()
        if actual_sha != meta["sha256"]:
            print(f"[!] SHA-256 mismatch on {rel_path}: {actual_sha} != {meta['sha256']}", file=sys.stderr)
            sys.exit(1)
    print("  ✓ All file digests match MANIFEST.json.")


def verify_adversarial_file(fpath: Path):
    data = json.loads(fpath.read_text(encoding="utf-8"))
    incident = data["incident_evidence"]
    claimed_digest = data["evidence_digest"]
    recomputed_digest = hashlib.sha256(encode_jcs(incident)).hexdigest()
    if claimed_digest != recomputed_digest:
        raise ValueError(f"Evidence digest mismatch in {fpath.name}")

    pubkey_pem = data["boundary_public_key_pem"]
    pub = serialization.load_pem_public_key(pubkey_pem.encode("utf-8"))
    if not isinstance(pub, Ed25519PublicKey):
        raise ValueError(f"Public key in {fpath.name} is not Ed25519PublicKey")

    sig_b64 = data["boundary_signature_b64"]
    sig_bytes = base64.b64decode(sig_b64)
    pub.verify(sig_bytes, encode_jcs(incident))


def verify_temporal_file(fpath: Path, pubkey_path: Path):
    data = json.loads(fpath.read_text(encoding="utf-8"))
    bundle_digest = data["bundle_digest"]
    clean_digest = bundle_digest.replace("sha256:", "")
    recomputed_digest = hashlib.sha256(encode_jcs(data["evidence_bundle"])).hexdigest()
    if clean_digest != recomputed_digest:
        raise ValueError(f"Bundle digest mismatch in {fpath.name}")

    pub_pem = pubkey_path.read_bytes()
    pub = serialization.load_pem_public_key(pub_pem)
    sig_b64 = data["bundle_signature"]["signature_b64"]
    sig_bytes = base64.b64decode(sig_b64)
    pub.verify(sig_bytes, encode_jcs(data["evidence_bundle"]))


def main():
    print("=" * 80)
    print("  AEIB ZERO-MOCK BENCHMARK PACK VERIFIER (v1.1.0)")
    print("  Evaluated under the stated model. Preserves strict epistemic lock.")
    print("=" * 80)

    verify_manifest()

    print("[*] Verifying Proof 1 (MITRE T1048 Exfiltration Prevention)...")
    p1_a = PACK_DIR / "proofs" / "proof_1_exfiltration" / "AT50_ai_enabled_exfiltration_evidence.json"
    p1_b = PACK_DIR / "proofs" / "proof_1_exfiltration" / "AT51_exfiltration_blocked_evidence.json"
    verify_adversarial_file(p1_a)
    verify_adversarial_file(p1_b)
    print("  ✓ Proof 1 Ed25519 signatures and RFC 8785 JCS digests valid.")

    print("[*] Verifying Proof 2 (Temporal State Drift Protection)...")
    p2_ev = PACK_DIR / "proofs" / "proof_2_temporal_drift" / "AT31_pre_execution_evidence.json"
    p2_key = PACK_DIR / "proofs" / "proof_2_temporal_drift" / "test_station1_pubkey.pem"
    verify_temporal_file(p2_ev, p2_key)
    print("  ✓ Proof 2 Ed25519 signatures and RFC 8785 JCS digests valid.")

    print("[*] Verifying Proof 3 (MITRE T1565 AI Result Poisoning Immunity)...")
    p3_a = PACK_DIR / "proofs" / "proof_3_result_poisoning" / "AT49_ai_result_poisoning_evidence.json"
    p3_b = PACK_DIR / "proofs" / "proof_3_result_poisoning" / "AT48_hostile_tool_output_evidence.json"
    verify_adversarial_file(p3_a)
    verify_adversarial_file(p3_b)
    print("  ✓ Proof 3 Ed25519 signatures and RFC 8785 JCS digests valid.")

    print("[*] Verifying Proof 4 (500-Episode Chaos Simulation Report)...")
    p4_results = PACK_DIR / "proofs" / "proof_4_chaos_simulation" / "benchmark_results.json"
    bdata = json.loads(p4_results.read_text(encoding="utf-8"))
    aeib_arm = bdata["results"]["aeib"]
    assert aeib_arm["duplicate_mutations"] == 0, "Duplicate mutations detected in Arm 4"
    assert aeib_arm["duplicate_attempts_blocked"] == 302, "Duplicate retries not properly blocked"
    print(f"  ✓ Proof 4 verified: Arm 4 duplicate mutations = {aeib_arm['duplicate_mutations']} / 500.")
    print(f"  ✓ Rule-of-Three 95% Upper Bound: <= {aeib_arm['rule_of_three_95_upper_bound_pct']}%.")

    print("[*] Verifying Proof 5 (5-Arm Benchmark Report)...")
    p5_results = PACK_DIR / "proofs" / "proof_4_chaos_simulation" / "results_5arm_benchmark.json"
    if p5_results.exists():
        b5data = json.loads(p5_results.read_text(encoding="utf-8"))
        res5 = b5data["results"]
        assert res5["arm_1_naive_retry"]["duplicate_mutations"] > 0
        assert res5["arm_2_semantic_drift"]["duplicate_mutations"] > 0
        assert res5["arm_3_server_stable_key"]["duplicate_mutations"] == 0
        assert res5["arm_3_server_stable_key"]["unresolved_episodes"] > 0
        assert res5["arm_4_stable_key_reconciled"]["duplicate_mutations"] == 0
        assert res5["arm_4_stable_key_reconciled"]["signed_cryptographic_receipts"] is False
        assert res5["arm_5_aeib_full_protocol"]["duplicate_mutations"] == 0
        assert res5["arm_5_aeib_full_protocol"]["pre_dispatch_journal_entries"] == 500
        assert res5["arm_5_aeib_full_protocol"]["signed_cryptographic_receipts"] == 500
        assert res5["arm_5_aeib_full_protocol"]["offline_verifiability"] is True
        assert res5["arm_5_aeib_full_protocol"]["crash_survivability"] is True
        print(f"  ✓ Proof 5 verified: Arm 5 duplicates = 0/500, journal entries = 500, receipts = 500.")

    print("[*] Verifying Integration Quality Gates Report (G1-G7)...")
    gates_report_path = PACK_DIR / "gates" / "integration_gates_g1_g7_report.json"
    if gates_report_path.exists():
        gdata = json.loads(gates_report_path.read_text(encoding="utf-8"))
        rep = gdata.get("report", gdata)
        assert rep["all_local_prerequisites_passed"] is True
        assert rep["all_gates_passed"] is False
        assert rep["gates"]["G6_separate_party_reproduced"]["status"] == "LOCAL_PREREQUISITES_PASS_EXTERNAL_PARTY_PENDING"
        assert rep["gates"]["G7_customer_pilot_accepted"]["status"] == "LOCAL_PREREQUISITES_PASS_EXTERNAL_PARTY_PENDING"
        rep_jcs = encode_jcs(rep)
        recomputed_rep_digest = hashlib.sha256(rep_jcs).hexdigest()
        clean_rep_digest = gdata["report_digest"].replace("sha256:", "")
        if clean_rep_digest != recomputed_rep_digest:
            raise ValueError(f"Gates report digest mismatch: {clean_rep_digest} != {recomputed_rep_digest}")
        sig_info = gdata.get("signature", {})
        g_pub_pem = sig_info.get("public_key_pem", gdata.get("boundary_public_key_pem", ""))
        g_pub = serialization.load_pem_public_key(g_pub_pem.encode("utf-8"))
        g_sig_b64 = sig_info.get("signature_b64", gdata.get("boundary_signature_b64", ""))
        g_sig_bytes = base64.b64decode(g_sig_b64)
        g_pub.verify(g_sig_bytes, rep_jcs)
        print("  ✓ Integration Gates G1-G7 report signature and JCS digest valid.")

    print("=" * 80)
    print("  ALL EVIDENCE BUNDLES VERIFIED: ZERO MOCKS, CRYPTOGRAPHIC DETERMINISM OBSERVED")
    print("=" * 80)


if __name__ == "__main__":
    main()
